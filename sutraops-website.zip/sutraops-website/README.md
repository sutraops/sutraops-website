# SutraOps Solutions — Website

Static homepage for **SutraOps Solutions** (SAP Consulting · Finance & Accounting · Intelligent Automation · Travel Services).

Built with plain **HTML + CSS + JavaScript** — no build tools, no dependencies. Deploys free on **GitHub Pages**.

## 📁 Files

| File | Purpose |
|------|---------|
| `index.html` | Page structure & content |
| `styles.css` | All styling / layout / responsive design |
| `script.js`  | Mobile menu, scroll highlight, animated stats |
| `assets/so-icon.png` | Your SO logo mark (transparent) — header + orbit + favicon |
| `assets/logo-full.png` | Your full logo with tagline (transparent) — for future use |

> ⚠️ **Important:** Upload the whole `assets/` folder to GitHub too, otherwise the logo won't show.

## 🚀 Deploy on GitHub Pages (free)

1. Create a GitHub account → https://github.com
2. Click **New repository**, name it `sutraops-website`, set to **Public**, click **Create**.
3. Click **Add file → Upload files**, drag in `index.html`, `styles.css`, `script.js`, `README.md` **and the entire `assets` folder**, then **Commit changes**.
4. Go to **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **Deploy from a branch**.
6. Select **Branch = main**, **Folder = / (root)**, click **Save**.
7. Wait ~1 minute. Your live site appears at:
   ```
   https://<your-username>.github.io/sutraops-website/
   ```

## ✏️ How to edit

- **Phone / email / text** → open `index.html` and change the words directly.
- **Colours** → edit the variables at the top of `styles.css` (`:root { ... }`).
- **WhatsApp number** → search `919288223003` in `index.html` and replace.

## 🔧 Notes

- The logo uses your real image (transparent background), shown in the header, orbit centre and browser-tab favicon.
- Fully mobile-responsive (test by resizing the browser).
- To use a custom domain (e.g. `www.sutraops.com`), add it under **Settings → Pages → Custom domain**.
